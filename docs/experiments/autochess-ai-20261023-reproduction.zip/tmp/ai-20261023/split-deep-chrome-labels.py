"""Seed-separated training data from audited actual Chrome high-level games."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
source = root / "chrome-labels-deep-live.json"
raw = source.read_bytes()
data = json.loads(raw)
assert data["contexts"] == data["expectedContexts"]
assert not data["errors"]
assert data["runtime"]["engine"] == "Chrome Worker" and data["combatHz"] == 60
assert all((a["actualScore"] >= 5000) == a["won"] for a in data["audits"])
seeds = {a["seed"] for a in data["audits"]}
assert seeds == set(range(90232, 90244)), seeds
rules = json.loads((root / "chrome-labels-rules.json").read_text(encoding="utf-8"))
for name, holdout in [("train", False), ("holdout", True)]:
    entries = [entry for entry in data["entries"]
               if (int(entry[0].split("/")[2].removeprefix("enemy:")) >= 90240) == holdout]
    audits = [a for a in data["audits"] if (a["seed"] >= 90240) == holdout]
    assert entries and audits
    payload = {**data, "entries": entries, "audits": audits,
               "contexts": len(audits), "expectedContexts": len(audits),
               "loaderSourceFingerprint": data["sourceFingerprint"],
               "sourceFingerprint": rules["sourceFingerprint"],
               "parentSha256": hashlib.sha256(raw).hexdigest(),
               "splitBySeed": name, "level": "deep",
               "seeds": sorted({a["seed"] for a in audits})}
    target = root / f"chrome-labels-deep-{name}.json"
    target.write_text(json.dumps(payload), encoding="utf-8")
    print(name, len(entries), "entries", len(audits), "contexts", payload["seeds"])
