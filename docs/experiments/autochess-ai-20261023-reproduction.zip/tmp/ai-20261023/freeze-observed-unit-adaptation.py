"""Preserve unknown fallback for an unobserved, hidden unit before acceptance."""
from pathlib import Path
import copy
import hashlib
import json
import shutil

root = Path(__file__).resolve().parent
source = root / "goCombatModel-missing-units.json"
model = json.loads(source.read_text(encoding="utf-8"))
observed = set()
for name in ["chrome-labels-train.json", "chrome-labels-deep-train.json"]:
    data = json.loads((root / name).read_text(encoding="utf-8"))
    for key, _ in data["entries"]:
        parts = key.split("/")
        observed.update(token.split(":")[0] for token in parts[8].split(",") if token)
        observed.update(token.split(":")[1] for token in parts[9].split(",") if token)
excluded = set(model["adaptation"]["newUnits"]) - observed
assert excluded == {"akirinco"}
kept = [index for index, unit in enumerate(model["vocab"]["units"]) if unit not in excluded]
export = copy.deepcopy(model)
export["vocab"]["units"] = [model["vocab"]["units"][index] for index in kept]
for name in ["unit_embedding.weight", "unit_features"]:
    export["state"][name] = [model["state"][name][index] for index in kept]
export["adaptation"]["observedTrainedUnits"] = sorted(set(model["adaptation"]["newUnits"]) & observed)
export["adaptation"]["unobservedUnitsUsingExactOriginalUnknown"] = sorted(excluded)
export["adaptation"]["exportTransform"] = {
    "parentSha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "scriptSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "method": "Remove only the untrained hidden-unit vocabulary/embedding rows; no numerical weight changes.",
}
output = root / "goCombatModel-observed-units.json"
destination = root / "chrome-observed-unit-embeddings"
assert not output.exists() and not destination.exists()
output.write_text(json.dumps(export, separators=(",", ":")), encoding="utf-8")
shutil.copytree(root / "chrome-missing-unit-embeddings" / "src", destination / "src")
shutil.copyfile(output, destination / "src/components/autoChessGame/ai/goCombatModelMissingUnits.json")
print(json.dumps({"output": str(output), "candidate": str(destination),
    "trainedUnits": export["adaptation"]["observedTrainedUnits"], "excludedUnobserved": sorted(excluded)}))
