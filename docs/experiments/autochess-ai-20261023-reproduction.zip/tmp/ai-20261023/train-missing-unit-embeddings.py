"""Fit only missing unit embeddings; preserve every original inference weight."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import random
import sys

import torch
from torch.nn import functional as F

root = Path(__file__).resolve().parent
repo = root.parent.parent
spec = importlib.util.spec_from_file_location("ranker", repo / "scripts/train-autochess-go-value.py")
m = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = m
spec.loader.exec_module(m)
previous_path = root / "reference/src/components/autoChessGame/ai/goCombatModel.json"
previous = json.loads(previous_path.read_text(encoding="utf-8"))
files = [root / "chrome-labels-train.json", root / "chrome-labels-deep-train.json"]
examples, stats, static = m.load_examples(files, 60)
feature_names = previous["unitFeatureNames"]
feature_indices = [static["names"].index(name) for name in feature_names]
vocab = copy.deepcopy(previous["vocab"])
missing = sorted(set(static["values"]) - set(vocab["units"]))
assert missing == ["akirinco", "chu2u", "sumire", "viridis"]
old_count = len(vocab["units"])
vocab["units"].extend(missing)
features = torch.tensor([[static["values"].get(key, [0.] * len(static["names"]))[i]
                          for i in feature_indices] for key in vocab["units"]])
torch.set_num_threads(1)
torch.manual_seed(20261023)
rng = random.Random(20261023)
train = [e for e in examples if m.stable_bucket(e.context_key) != 0
         and any(unit in missing for unit, _, _ in (*e.players, *e.enemies))]
validation = [e for e in examples if m.stable_bucket(e.context_key) == 0
              and any(unit in missing for unit, _, _ in (*e.players, *e.enemies))]
assert train and validation
mean, std = previous["normalization"]["modifierMean"], previous["normalization"]["modifierStd"]
device = torch.device("cpu")
encoded = m.EncodedSplit(train, vocab, mean, std, device).tensors
held = m.EncodedSplit(validation, vocab, mean, std, device).tensors
model = m.GoCombatRanker(vocab, len(previous["state"]["enemy_position_embedding.weight"]), features)
m.initialize_model(model, previous, vocab, feature_names)
for parameter in model.parameters():
    parameter.requires_grad_(False)
embedding = model.unit_embedding.weight
embedding.requires_grad_(True)
mask = torch.zeros_like(embedding)
mask[old_count:] = 1
embedding.register_hook(lambda gradient: gradient * mask)
anchor = embedding.detach().clone()
optimizer = torch.optim.Adam([embedding], lr=.01)
best = anchor.clone()
best_loss = float("inf")
best_epoch = 0
def validation_loss():
    with torch.no_grad():
        prediction = model(held)
        return F.binary_cross_entropy_with_logits(prediction, (held["target"] >= 0).float()).item()
before = validation_loss()
for epoch in range(1, 601):
    index = torch.tensor(rng.choices(range(len(train)), k=min(512, len(train))))
    batch = {key: value[index] for key, value in encoded.items()}
    prediction = model(batch)
    loss = F.binary_cross_entropy_with_logits(prediction, (batch["target"] >= 0).float())
    loss += .03 * (embedding[old_count:] - anchor[old_count:]).square().mean()
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    with torch.no_grad():
        embedding[:old_count].copy_(anchor[:old_count])
        embedding[old_count:].copy_(anchor[old_count:] + (embedding[old_count:] - anchor[old_count:]).clamp(-1.5, 1.5))
    if epoch % 25 == 0:
        value = validation_loss()
        if value < best_loss:
            best_loss, best_epoch, best = value, epoch, embedding.detach().clone()
        if epoch - best_epoch >= 150:
            break
with torch.no_grad():
    embedding.copy_(best)
payload = copy.deepcopy(previous)
payload["vocab"] = vocab
payload["state"]["unit_embedding.weight"] += [[round(float(x), 6) for x in row] for row in best[old_count:]]
payload["state"]["unit_features"] += features[old_count:].tolist()
for name, values in previous["state"].items():
    if name not in ("unit_features", "unit_embedding.weight"):
        assert payload["state"][name] == values
assert payload["state"]["unit_embedding.weight"][:old_count] == previous["state"]["unit_embedding.weight"]
payload["adaptation"] = {
    "method": "Only four missing embedding rows; all original weights, features and normalization unchanged.",
    "newUnits": missing, "trainExamples": len(train), "validationExamples": len(validation),
    "seed": 20261023, "bestEpoch": best_epoch, "validationBceBefore": before, "validationBceAfter": best_loss,
    "maximumEmbeddingDelta": 1.5,
    "learnerSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "parentModelSha256": hashlib.sha256(previous_path.read_bytes()).hexdigest(),
    "data": [{"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in files],
}
output = root / "goCombatModel-missing-units.json"
output.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
print(json.dumps(payload["adaptation"], indent=2))
