import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
source = root / 'chrome-labels-live.json'
raw = source.read_bytes()
data = json.loads(raw)
rules = json.loads((root / 'chrome-labels-rules.json').read_text(encoding='utf-8'))
assert data['contexts'] == data['expectedContexts']
assert data['runtime']['engine'] == 'Chrome Worker' and data['runtime']['hz'] == 60
assert not data['errors']
assert all((a['actualScore'] >= 5000) == a['won'] for a in data['audits'])

for name, held in [('train', False), ('holdout', True)]:
    entries = [entry for entry in data['entries']
               if (int(entry[0].split('/')[2].removeprefix('enemy:')) >= 90224) == held]
    assert entries
    payload = {**data, 'entries': entries,
               'loaderSourceFingerprint': data['sourceFingerprint'],
               'sourceFingerprint': rules['sourceFingerprint'],
               'audits': [audit for audit in data['audits'] if (audit['seed'] >= 90224) == held],
               'parentSha256': hashlib.sha256(raw).hexdigest(),
               'splitBySeed': name}
    payload['contexts'] = len(payload['audits'])
    target = root / f'chrome-labels-{name}.json'
    target.write_text(json.dumps(payload), encoding='utf-8')
    print(name, len(entries), 'contexts', payload['contexts'])
