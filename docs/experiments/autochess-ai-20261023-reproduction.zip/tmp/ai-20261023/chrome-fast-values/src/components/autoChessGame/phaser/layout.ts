/** Stable authored coordinates for every card, slot, panel, and hit area. */
import type { GamePhase } from "../core/gameTypes";

export const WORLD_WIDTH = 1120;
export const WORLD_HEIGHT = 720;
export const TOOLBAR_HEIGHT = 42;
export const MAX_PORTRAIT_VIEWPORT_WIDTH = 1200;
/**
 * Portrait battle uses a dedicated logical frame. The simulation still runs
 * in the authored 1120×720 arena; the scene maps that arena into this frame
 * so a phone can show the whole encounter without shrinking it to a strip.
 */
export const MOBILE_BATTLE_LOGICAL_WIDTH = 480;
export const MOBILE_BATTLE_LOGICAL_HEIGHT = 900;
export const MOBILE_BATTLE_FIELD_FRAME = {
  x: 16,
  y: 132,
  width: 448,
  height: 680,
} as const;
export const MOBILE_BATTLE_PRESENTATION = {
  scaleX: MOBILE_BATTLE_FIELD_FRAME.width / 1072,
  scaleY: MOBILE_BATTLE_FIELD_FRAME.height / 596,
  offsetX: MOBILE_BATTLE_FIELD_FRAME.x - 24 * (MOBILE_BATTLE_FIELD_FRAME.width / 1072),
  offsetY: MOBILE_BATTLE_FIELD_FRAME.y - 94 * (MOBILE_BATTLE_FIELD_FRAME.height / 596),
} as const;
export const MIN_UI_SCALE = 1;
export const MAX_UI_SCALE = 1.25;
export const UI_SCALE_BASE_WIDTH = 1280;
export const UI_SCALE_BASE_HEIGHT = 720;
export const MIN_CARD_SCALE = 0.72;
export const MAX_CARD_SCALE = 1.25;
/** Legacy compact helpers remain declared while their mobile profile is disabled. */
export const MOBILE_TOUCH_TARGET = 54;

/** Prevent a fullscreen, high-DPI canvas from allocating an unbounded framebuffer. */
export const MAX_RENDER_PIXELS = 8_000_000;
export const MAX_DEVICE_PIXEL_RATIO = 2;
export const MAX_MOBILE_DEVICE_PIXEL_RATIO = 1.5;
export const MAX_TEXT_RESOLUTION = 2;
export const MAX_MOBILE_TEXT_RESOLUTION = 1.5;

export type RenderSize = {
  width: number;
  height: number;
  renderScale: number;
  devicePixelRatio: number;
};

/**
 * Give roomy desktop viewports the same visual density as 125% browser zoom.
 * Smaller windows continuously fall back to the original 100% layout.
 */
export const uiScaleFor = (width: number, height: number) => Math.min(
  MAX_UI_SCALE,
  Math.max(
    MIN_UI_SCALE,
    Math.min(width / UI_SCALE_BASE_WIDTH, height / UI_SCALE_BASE_HEIGHT),
  ),
);

/**
 * Size the physical Phaser drawing surface from its actual CSS host. The scene
 * owns the logical aspect ratio, so portrait hosts must not inherit the desktop
 * 1120×720 backing-buffer ratio.
 */
export const renderSizeFor = (displayWidth: number, displayHeight: number, devicePixelRatio: number): RenderSize => {
  const mobileSized = Math.min(displayWidth, displayHeight) <= 700
    && Math.max(displayWidth, displayHeight) <= 1200;
  const maximumDensity = mobileSized ? MAX_MOBILE_DEVICE_PIXEL_RATIO : MAX_DEVICE_PIXEL_RATIO;
  const requestedDensity = Math.max(1, Math.min(maximumDensity, devicePixelRatio || 1));
  const displayPixels = Math.max(1, displayWidth * displayHeight);
  const budgetDensity = Math.sqrt(MAX_RENDER_PIXELS / displayPixels);
  const density = Math.max(1, Math.min(requestedDensity, budgetDensity));

  return {
    width: Math.max(1, Math.round(displayWidth * density)),
    height: Math.max(1, Math.round(displayHeight * density)),
    renderScale: density,
    devicePixelRatio: density,
  };
};

export type LayoutProfile = "wide" | "compact";

export const isPortraitViewport = (width: number, height: number) => (
  width > 0
  && width <= MAX_PORTRAIT_VIEWPORT_WIDTH
  && height > width * 1.12
);

export const logicalSizeForPhase = (width: number, height: number, phase: GamePhase) => {
  if (isPortraitViewport(width, height) && phase === "preparation") {
    return { width: 480, height: 1000 };
  }
  if (isPortraitViewport(width, height) && phase === "battle") {
    return { width: MOBILE_BATTLE_LOGICAL_WIDTH, height: MOBILE_BATTLE_LOGICAL_HEIGHT };
  }
  return { width: WORLD_WIDTH, height: WORLD_HEIGHT };
};

export type ViewportScale = {
  fitScale: number;
  cardScale: number;
  compact: boolean;
};

/**
 * DPR is intentionally absent: it changes render density, never authored UI geometry.
 * `fitScale` is the actual camera scale; `cardScale` is the bounded readability target
 * used to choose the compact information profile when the host is too small.
 */
export const viewportScaleFor = (usableWidth: number, usableHeight: number): ViewportScale => {
  const fitScale = Math.max(0.01, Math.min(usableWidth / WORLD_WIDTH, usableHeight / WORLD_HEIGHT));
  return {
    fitScale,
    cardScale: Math.min(MAX_CARD_SCALE, Math.max(MIN_CARD_SCALE, fitScale)),
    compact: fitScale < MIN_CARD_SCALE,
  };
};

/**
 * Tooltip typography is expressed in CSS-sized visual units. Its container
 * cancels the camera fit scale so a narrower browser does not shrink it.
 * DPR remains a text-texture quality concern in the scene, not a font-size input.
 */
export const TOOLTIP_TYPOGRAPHY = {
  title: 20,
  body: 14,
  section: 14,
  traitHeading: 12,
  tag: 12,
  padding: 20,
  tagHeight: 24,
  tagGap: 5,
  pointerOffset: 18,
  edgeInset: 12,
} as const;

export type TooltipLayout = {
  scale: number;
  width: number;
};

export const tooltipLayoutFor = (usableWidth: number, usableHeight: number, preferredWidth: number): TooltipLayout => {
  const { fitScale } = viewportScaleFor(usableWidth, usableHeight);
  return {
    scale: 1 / fitScale,
    width: Math.max(1, Math.min(preferredWidth, usableWidth - TOOLTIP_TYPOGRAPHY.edgeInset * 2)),
  };
};

export const PREPARATION_BOARD_PANEL = { x: 26, y: 98, width: 752, height: 430 };
export const PREPARATION_SHOP_PANEL = { x: 794, y: 98, width: 300, height: 500 };
export const PREPARATION_BENCH_PANEL = { x: 26, y: 548, width: 752, height: 148 };
export const PREPARATION_SELL_ZONE = { x: 628, y: 552, width: 136, height: 35 };
export const WIDE_TRAIT_STRIP = { x: 48, y: 190, width: 700, height: 25 };
export const COMPACT_TRAIT_STRIP = { x: 48, y: 194, width: 1028, height: 25 };
export const MOBILE_TRAIT_STRIP = { x: 16, y: 126, width: 448, height: 32 };
export const MOBILE_BOARD_PANEL = { x: 16, y: 172, width: 448, height: 244 };
export const MOBILE_BENCH_PANEL = { x: 16, y: 428, width: 448, height: 168 };
export const MOBILE_SHOP_PANEL = { x: 16, y: 608, width: 448, height: 112 };

export const occupiedSlotLayout = (
  rect: { x: number; y: number; width: number; height: number },
  isBench: boolean,
  compact: boolean,
) => ({
  portraitRadius: compact ? (isBench ? 22 : 21) : isBench ? 24 : 22,
  portraitY: rect.y + rect.height / 2,
  starX: rect.x + 6,
  starY: rect.y + 7,
  nameX: rect.x + 6,
  nameY: rect.y + rect.height - 7,
  valueX: rect.x + rect.width - 6,
  valueY: rect.y + rect.height - 7,
  nameWidth: isBench ? rect.width - (compact ? 43 : 46) : rect.width - 12,
});

export type ResultLayout = {
  panel: { x: number; y: number; width: number; height: number };
  kickerY: number;
  headlineY: number;
  detailY: number;
  rewardY: number;
  debriefY: number;
  metricsY: number;
  rosterHeadingY: number;
  rosterY: number;
  rosterBottom: number;
  columnX: readonly [number, number];
  columnWidth: number;
  continueY: number;
  headlineSize: number;
  detailSize: number;
};

export const WIDE_RESULT_LAYOUT: ResultLayout = {
  panel: { x: 42, y: 96, width: 1036, height: 600 },
  kickerY: 116,
  headlineY: 141,
  detailY: 164,
  rewardY: 198,
  debriefY: 219,
  metricsY: 254,
  rosterHeadingY: 290,
  rosterY: 310,
  rosterBottom: 628,
  columnX: [64, 564],
  columnWidth: 468,
  continueY: 646,
  headlineSize: 24,
  detailSize: 10,
};

export const COMPACT_RESULT_LAYOUT: ResultLayout = {
  panel: { x: 26, y: 88, width: 1068, height: 612 },
  kickerY: 108,
  headlineY: 132,
  detailY: 154,
  rewardY: 190,
  debriefY: 211,
  metricsY: 246,
  rosterHeadingY: 282,
  rosterY: 302,
  rosterBottom: 626,
  columnX: [46, 566],
  columnWidth: 496,
  continueY: 648,
  headlineSize: 22,
  detailSize: 9,
};

export const boardSlot = (index: number) => ({
  x: 44 + (index % 6) * 116 + (Math.floor(index / 6) % 2) * 20,
  y: 232 + Math.floor(index / 6) * 68,
  width: 104,
  height: 58,
});

export const benchSlot = (index: number) => ({
  x: 48 + index * 88,
  y: 600,
  width: 80,
  height: 76,
});

export const compactBoardSlot = (index: number) => ({
  x: 30 + (index % 6) * 177,
  y: 238 + Math.floor(index / 6) * 63,
  width: 156,
  height: 53,
});

export const compactBenchSlot = (index: number) => ({
  x: 42 + index * 130,
  y: 488,
  width: 116,
  height: 60,
});

/** Six-by-four board keeps every portrait target at least 54 CSS px on a 390 px phone. */
export const mobileBoardSlot = (index: number) => ({
  x: 24 + (index % 6) * 73,
  y: 190 + Math.floor(index / 6) * 54,
  width: 66,
  height: 48,
});

/** The nine-slot bench is a 3×3 grid rather than a desktop-width row. */
export const mobileBenchSlot = (index: number) => ({
  x: 24 + (index % 3) * 146,
  y: 442 + Math.floor(index / 3) * 50,
  width: 136,
  height: 44,
});

export type TitleLayout = {
  eyebrowY: number;
  titleY: number;
  summaryY: number;
  promptY: number;
  cardY: number;
  cardWidth: number;
  cardHeight: number;
  cardXs: readonly [number, number, number];
  portraitY: number;
  subtitleY: number;
  nameY: number;
  descriptionY: number;
  descriptionWidth: number;
  ctaY: number;
  seedY: number;
  controlsY: number;
};

export const WIDE_TITLE_LAYOUT: TitleLayout = {
  eyebrowY: 126,
  titleY: 166,
  summaryY: 232,
  promptY: 264,
  cardY: 318,
  cardWidth: 300,
  cardHeight: 260,
  cardXs: [90, 410, 730],
  portraitY: 58,
  subtitleY: 108,
  nameY: 138,
  descriptionY: 164,
  descriptionWidth: 252,
  ctaY: 218,
  seedY: 626,
  controlsY: 666,
};

export const COMPACT_TITLE_LAYOUT: TitleLayout = {
  eyebrowY: 108,
  titleY: 144,
  summaryY: 198,
  promptY: 224,
  cardY: 266,
  cardWidth: 310,
  cardHeight: 260,
  cardXs: [50, 405, 760],
  portraitY: 58,
  subtitleY: 108,
  nameY: 138,
  descriptionY: 164,
  descriptionWidth: 260,
  ctaY: 218,
  seedY: 574,
  controlsY: 612,
};

export const titleLayoutFor = (profile: LayoutProfile) => (profile === "compact" ? COMPACT_TITLE_LAYOUT : WIDE_TITLE_LAYOUT);

export const starterCardRect = (index: number, profile: LayoutProfile) => {
  const layout = titleLayoutFor(profile);
  return { x: layout.cardXs[index] ?? layout.cardXs[0], y: layout.cardY, width: layout.cardWidth, height: layout.cardHeight };
};

export const profileFor = (width: number, height: number): LayoutProfile => (
  viewportScaleFor(width, height).compact ? "compact" : "wide"
);
