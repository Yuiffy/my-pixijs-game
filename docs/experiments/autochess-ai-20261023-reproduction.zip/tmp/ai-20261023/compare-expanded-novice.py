import hashlib
import importlib.util
import json
from pathlib import Path

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('paired', root.parent.parent / 'scripts/compare-autochess-muzero.py')
paired = importlib.util.module_from_spec(spec)
spec.loader.exec_module(paired)
protocol = json.loads((root / 'expanded-novice-protocol.json').read_text(encoding='utf-8'))
assert protocol['groups'] == [92000, 92100, 93000, 93100]
reports = [[], []]
digests = {}
for seed in protocol['groups']:
    for side, variant in enumerate(['reference', 'chrome-unit-values']):
        path = root / f'accept-{variant}-novice-{seed}.json'
        raw = path.read_bytes()
        report = json.loads(raw)
        assert report['config']['seed'] == seed and report['config']['runs'] == 32
        assert report['config']['level'] == 'novice' and report['config']['battles'] == 32
        assert {r['seed'] for r in report['results']} == set(range(seed, seed + 32))
        reports[side].append(report)
        digests[path.name] = hashlib.sha256(raw).hexdigest()
for side in reports:
    assert len({r['fingerprint'] for r in side}) == 1
    assert len({json.dumps(r['runtime'], sort_keys=True) for r in side}) == 1
    seeds = [x['seed'] for r in side for x in r['results']]
    assert len(seeds) == len(set(seeds)) == 128
groups = [paired.compare(a, b, 32) for a, b in zip(*reports)]
merged = [{**side[0], 'results': [x for r in side for x in r['results']]} for side in reports]
combined = paired.compare(*merged, 128)
checks = {
    'allGroupsImprove': all(g['meanWinDelta'] > 0 for g in groups),
    'meanAtLeastQuarterWin': combined['meanWinDelta'] >= .25,
    'noFewerClears': combined['clearDelta'] >= 0,
    'earlyEndsWithinOne': combined['earlyEndDelta'] <= 1,
    'bootstrapPositiveAtLeast80Percent': combined['bootstrapPositiveFraction'] >= .8,
}
result = {'protocol': protocol, 'original64Passed': False, 'groups': groups,
          'combined': combined, 'checks': checks, 'passed': all(checks.values()), 'inputSha256': digests}
(root / 'acceptance-expanded-chrome-unit-values-novice.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print(json.dumps({'groups': [{k: g[k] for k in ['meanWinDelta', 'clearDelta', 'earlyEndDelta']} for g in groups],
                  'combined': {k: combined[k] for k in ['meanWinDelta', 'clearDelta', 'earlyEndDelta', 'pairedBootstrap95', 'bootstrapPositiveFraction']},
                  'checks': checks, 'passed': result['passed']}, indent=2))
