import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { loadTypescriptModule } from '../../scripts/tests/helpers/load-typescript-module.mjs';

const root = 'tmp/ai-20261023/';
const ai = 'src/components/autoChessGame/ai/';
const setup = async name => {
  const prefix = `${root}${name}/`;
  const module = await loadTypescriptModule(`${prefix}${ai}goValueModel.ts`);
  const scoreOriginal = module.scoreGoCombatCandidate;
  const createOriginal = module.createGoCombatScorer;
  const calls = { original: 0, adapted: 0 };
  module.scoreGoCombatCandidate = evaluation => {
    calls.original += 1;
    return scoreOriginal(evaluation);
  };
  module.createGoCombatScorer = model => {
    const scorer = createOriginal(model);
    return evaluation => {
      calls.adapted += 1;
      return scorer(evaluation);
    };
  };
  const { EngineBridge } = await loadTypescriptModule(`${prefix}src/components/autoChessGame/phaser/EngineBridge.ts`);
  const { AutoChessAutopilot } = await loadTypescriptModule(`${prefix}${ai}AutoChessAutopilot.ts`);
  const bridge = new EngineBridge(90232, 1, { simulation: true });
  bridge.setConsoleLogging(false);
  const pilot = new AutoChessAutopilot(bridge, 'evolution', {}, 'balanced', 'normal', 20,
    undefined, true, 'veteran', true);
  return { calls, bridge, pilot, AutoChessAutopilot,
    reset: () => { calls.original = 0; calls.adapted = 0; } };
};
const baseline = await setup('chrome-fast-values');
const candidate = await setup('chrome-observed-unit-embeddings');
const entry = { unit: { uid: 1, id: 'sumire', star: 2 }, location: { zone: 'board', index: 10 } };
const placements = [{ entry, slot: 10 }];
const records = [];
for (const level of ['novice', 'veteran', 'deep', 'oracle', 'go', 'veteran', 'oracle']) {
  for (const context of [baseline, candidate]) {
    context.pilot.setConfiguration('balanced', level);
    context.reset();
  }
  const a = baseline.pilot.goModelPlacementsScoreAtRound(placements, 12);
  const b = candidate.pilot.goModelPlacementsScoreAtRound(placements, 12);
  assert.equal(baseline.calls.original, 1);
  assert.equal(baseline.calls.adapted, 0);
  const high = ['deep', 'oracle'].includes(level);
  assert.deepEqual(candidate.calls, high ? { original: 0, adapted: 1 } : { original: 1, adapted: 0 });
  assert.ok(Number.isFinite(a) && Number.isFinite(b));
  if (!high) assert.equal(b, a);
  assert.equal(baseline.bridge.engine.state.round, 1);
  assert.equal(candidate.bridge.engine.state.round, 1);
  assert.equal(candidate.pilot.rolloutVariantLimit, baseline.pilot.rolloutVariantLimit);
  records.push({ level, baselineCalls: { ...baseline.calls }, candidateCalls: { ...candidate.calls } });
}
for (const round of [1, 12, 16, 21, 31]) {
  for (const context of [baseline, candidate]) {
    context.pilot.setConfiguration('balanced', 'oracle');
    context.bridge.engine.state.round = round;
    context.reset();
  }
  baseline.pilot.oracleFutureModelScore([entry], 'go_canonical');
  candidate.pilot.oracleFutureModelScore([entry], 'go_canonical');
  assert.equal(candidate.calls.original, 0);
  assert.equal(candidate.calls.adapted, baseline.calls.original);
  assert.ok(candidate.calls.adapted > 0);
  assert.deepEqual(candidate.pilot.oraclePlanningWindow(), baseline.pilot.oraclePlanningWindow());
  assert.equal(candidate.bridge.engine.state.round, round);
  assert.equal(baseline.bridge.engine.state.round, round);
  records.push({ round, futureBaselineCalls: baseline.calls.original, futureCandidateCalls: candidate.calls.adapted });
}
candidate.reset();
let customCalls = 0;
const custom = new candidate.AutoChessAutopilot(candidate.bridge, 'evolution', {}, 'balanced', 'normal', 20,
  () => { customCalls += 1; return 321; }, true, 'deep', true);
assert.equal(custom.goModelPlacementsScoreAtRound(placements, 12), 321);
assert.equal(customCalls, 1);
assert.deepEqual(candidate.calls, { original: 0, adapted: 0 });
const report = { passed: true, oneExistingInferenceReplacedByOneAdaptedInference: true,
  originalScorerForLowAndHiddenLevels: true, unchangedRolloutVariantLimits: true,
  unchangedOracleWindowsAndFutureInferenceCounts: true, customScorerPreserved: true, records };
writeFileSync(`${root}observed-runtime-budgets-verification.json`, JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
