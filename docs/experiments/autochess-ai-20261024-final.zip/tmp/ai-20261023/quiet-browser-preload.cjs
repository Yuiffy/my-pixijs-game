const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const path = require('node:path');
const localRequire = createRequire(path.join(process.cwd(), 'verify-autochess.cjs'));
let chromium;
for (const candidate of [process.env.PLAYWRIGHT_MODULE, 'playwright',
  'C:/Users/yuiffy/AppData/Local/npm-cache/_npx/9833c18b2d85bc59/node_modules/playwright'].filter(Boolean)) {
  try { ({ chromium } = localRequire(candidate)); break; } catch { /* Try installed runtime. */ }
}
assert.ok(chromium, 'Installed Playwright must be available');
const original = chromium.launchPersistentContext.bind(chromium);
chromium.launchPersistentContext = async (profile, options) => {
  assert.equal(options.channel, 'chrome');
  assert.ok(options.args.includes('--mute-audio'));
  const context = await original(profile, options);
  await context.addInitScript(() => {
    const request = () => Promise.resolve();
    Object.defineProperty(Element.prototype, 'requestPointerLock', { configurable: true, value: request });
    Object.defineProperty(document, 'exitPointerLock', { configurable: true, value: () => {} });
    window.__autoChessSafePointerRequest = request;
    if (window.speechSynthesis) window.speechSynthesis.speak = () => {};
  });
  const guard = page => {
    const navigate = page.goto.bind(page);
    page.goto = async (...args) => {
      const result = await navigate(...args);
      const safe = await page.evaluate(() =>
        Element.prototype.requestPointerLock === window.__autoChessSafePointerRequest
        && document.pointerLockElement === null
        && (!window.speechSynthesis || !window.speechSynthesis.speak.toString().includes('[native code]')));
      assert.ok(safe, 'Quiet test environment guard must be installed before interactions');
      console.log('QUIET_TEST_GUARD: installed Chrome, Pointer Lock stubbed, speech stubbed, --mute-audio');
      return result;
    };
  };
  context.pages().forEach(guard);
  context.on('page', guard);
  return context;
};
