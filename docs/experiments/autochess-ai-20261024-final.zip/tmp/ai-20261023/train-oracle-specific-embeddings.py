"""Offline fallback: adapt three existing rows using oracle training seeds only."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import random
import sys

import torch
from torch.nn import functional as F

root = Path(__file__).resolve().parent
repo = root.parent.parent
protocol = json.loads((root / "oracle-specific-embeddings-training-protocol.json").read_text(encoding="utf-8"))
for item in protocol["files"]:
    assert hashlib.sha256((repo / item["path"]).read_bytes()).hexdigest() == item["sha256"]
spec = importlib.util.spec_from_file_location("oracle_ranker", repo / "scripts/train-autochess-go-value.py")
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
parent_path = repo / "src/components/autoChessGame/ai/goCombatModelMissingUnits.json"
parent = json.loads(parent_path.read_text(encoding="utf-8"))
data_path = root / "chrome-labels-oracle-train.json"
examples, _, _ = module.load_examples([data_path], 60)
units = ["chu2u", "sumire", "viridis"]
examples = [e for e in examples if any(unit in units for unit, _, _ in (*e.players, *e.enemies))]
assert all(90244 <= e.enemy_seed <= 90251 for e in examples)
train = [e for e in examples if module.stable_bucket(e.context_key) != 0]
validation = [e for e in examples if module.stable_bucket(e.context_key) == 0]
assert train and validation
torch.set_num_threads(1)
torch.manual_seed(protocol["seed"])
rng = random.Random(protocol["seed"])
vocab = parent["vocab"]
features = torch.tensor(parent["state"]["unit_features"])
model = module.GoCombatRanker(vocab, len(parent["state"]["enemy_position_embedding.weight"]), features)
module.initialize_model(model, parent, vocab, parent["unitFeatureNames"])
for parameter in model.parameters():
    parameter.requires_grad_(False)
embedding = model.unit_embedding.weight
embedding.requires_grad_(True)
indices = [vocab["units"].index(unit) for unit in units]
mask = torch.zeros_like(embedding)
mask[indices] = 1
embedding.register_hook(lambda gradient: gradient * mask)
anchor = embedding.detach().clone()
optimizer = torch.optim.Adam([embedding], lr=protocol["learningRate"])
device = torch.device("cpu")
mean = parent["normalization"]["modifierMean"]
std = parent["normalization"]["modifierStd"]
encoded = module.EncodedSplit(train, vocab, mean, std, device).tensors
held = module.EncodedSplit(validation, vocab, mean, std, device).tensors


def validation_loss():
    with torch.no_grad():
        return F.binary_cross_entropy_with_logits(model(held), (held["target"] >= 0).float()).item()


before = validation_loss()
best_loss = before
best_epoch = 0
best = anchor.clone()
for epoch in range(1, protocol["maxEpochs"] + 1):
    sample = torch.tensor(rng.choices(range(len(train)), k=min(512, len(train))))
    batch = {key: value[sample] for key, value in encoded.items()}
    loss = F.binary_cross_entropy_with_logits(model(batch), (batch["target"] >= 0).float())
    loss += protocol["regularizationToAcceptedAnchor"] * (embedding[indices] - anchor[indices]).square().mean()
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    with torch.no_grad():
        limit = protocol["maximumCoordinateChangeFromAccepted"]
        delta = (embedding - anchor).clamp(-limit, limit) * mask
        embedding.copy_(anchor + delta)
    if epoch % 25 == 0:
        value = validation_loss()
        if value < best_loss:
            best_loss, best_epoch, best = value, epoch, embedding.detach().clone()
        if epoch - best_epoch >= protocol["patience"]:
            break

rows = {unit: [round(float(x), 6) for x in best[index]] for unit, index in zip(units, indices)}
assert all(abs(value - parent["state"]["unit_embedding.weight"][vocab["units"].index(unit)][i]) <= .750001
           for unit, row in rows.items() for i, value in enumerate(row))
payload = {
    "schema": "autochess-oracle-unit-embeddings-v1",
    "parentModelSha256": hashlib.sha256(parent_path.read_bytes()).hexdigest(),
    "unitEmbeddingRows": rows,
    "training": {"seed": protocol["seed"], "trainExamples": len(train), "validationExamples": len(validation),
                 "bestEpoch": best_epoch, "validationBceBefore": before, "validationBceAfter": best_loss,
                 "maximumCoordinateChangeFromAccepted": .75,
                 "learnerSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                 "dataSha256": hashlib.sha256(data_path.read_bytes()).hexdigest(),
                 "externalHoldoutUsedForTrainingOrEarlyStopping": False},
}
full = copy.deepcopy(parent)
for unit, row in rows.items():
    full["state"]["unit_embedding.weight"][vocab["units"].index(unit)] = row
full["adaptation"]["oracleSpecificAdaptation"] = payload["training"]
for name, data in [("oracleUnitEmbeddings.json", payload), ("goCombatModel-oracle-specific.json", full)]:
    path = root / name
    assert not path.exists(), "Preserve frozen offline artifacts"
    path.write_text(json.dumps(data, separators=(",", ":")), encoding="utf-8")
print(json.dumps(payload["training"], indent=2))
